
package com.fastgreg;

import net.minecraftforge.fml.common.Mod;

@Mod("fastgreg")
public class FastGreg {
    public FastGreg() {}
}
